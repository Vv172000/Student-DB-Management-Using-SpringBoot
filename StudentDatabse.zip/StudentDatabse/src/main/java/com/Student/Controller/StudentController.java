package com.Student.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Student.Model.Student;
import com.Student.Repository.StudentRepo;
import com.Student.Service.StudentService;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.PutMapping;


@Controller
public class StudentController {
	@Autowired
	StudentService studentservice;
	
	@GetMapping("/hello")
	public String springMVC() {
		return "index";
	}
	
	@PostMapping("/add")
	public void addStudent(@RequestBody Student student) {
		studentservice.addDetails(student);
	}
	
	@GetMapping("/readAll")
	public List<Student> readData() {
		return studentservice.readdata();
	}
	
	@GetMapping("/readById/{id}")
	public Optional<Student> readDataById(@PathVariable("id") Integer id) {
		 return studentservice.readSpecific(id);
	}
	
	@DeleteMapping("/deleteById/{id}")
	public String deleteById(@PathVariable("id") Integer id) {
		 return studentservice.deleteById(id);
	}
	
	@DeleteMapping("/deleteAll")
	public String delteAll() {
		 return studentservice.deleteAll();
	}
	@PutMapping("update/{id}/{phNo}/{year}")
	public String update(@PathVariable Integer id,@PathVariable Long phNo,@PathVariable Integer year) {
		return studentservice.update(id, phNo, year);
		
	
	}
	
	
}
