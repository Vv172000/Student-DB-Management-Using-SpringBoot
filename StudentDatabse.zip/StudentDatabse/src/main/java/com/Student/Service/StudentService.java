package com.Student.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Student.Model.Student;
import com.Student.Repository.StudentRepo;
@Service
public class StudentService {
	@Autowired
	StudentRepo studentrespo;
	
	public Student addDetails(Student student) {
		return studentrespo.save(student);
	}
	
	public List<Student> readdata() {
		return studentrespo.findAll();
	}
	
	public Optional<Student> readSpecific(Integer id) {
		return studentrespo.findById(id);
	}
	
	public String deleteById(Integer id) {
		 studentrespo.deleteById(id);
		 return "deleted successfully ";
	}
	
	public String deleteAll() {
		 studentrespo.deleteAll();
		 return "All the data in the database are deleted";
	}
	
	public String update(Integer id,Long phNo,Integer year) {
		Student student=studentrespo.findById(id).get();
		student.setPhNo(phNo);
		student.setYear(year);
		studentrespo.save(student);
		return "Updated Successfully";
	}

}
