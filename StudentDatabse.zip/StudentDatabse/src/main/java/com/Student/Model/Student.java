package com.Student.Model;

import java.time.LocalDate;

import org.springframework.data.annotation.Id;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;


@Entity
public class Student {
	
	 public Student() {
		super();
	}
	public int getStudentid() {
		return id;
	}
	public Student(String name, long phNo, LocalDate dob, String gender, String department, int year) {
		super();
		this.name = name;
		this.phNo = phNo;
		this.dob = dob;
		this.gender = gender;
		this.Department = department;
		this.year = year;
	}
	public void setStudentid(int studentid) {
		this.id = studentid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getPhNo() {
		return phNo;
	}
	public void setPhNo(long phNo) {
		this.phNo = phNo;
	}
	public LocalDate getDob() {
		return dob;
	}
	public void setDob(LocalDate dob) {
		this.dob = dob;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getDepartment() {
		return Department;
	}
	public void setDepartment(String department) {
		this.Department = department;
	}
	public long getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	@jakarta.persistence.Id
	 @GeneratedValue (strategy = GenerationType.IDENTITY)
	 int id;
	 String name;
	 long phNo;
	 LocalDate dob;
	 String gender;
	 String Department;
	 int year;
}
